# ssd1306-stm32HAL
ssd1306 library for stm32 using stm32-hal library's.

This library works with i2c.

If you search 4-wire SPI support, you can find it in the [afiskon/stm32-ssd1306](https://github.com/afiskon/stm32-ssd1306) fork.

The library files are: 
    
    - font.h
    - font.c 
    - ssd1306.h
    - ssd1306.c